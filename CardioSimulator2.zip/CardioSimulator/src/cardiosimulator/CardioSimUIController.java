/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardiosimulator;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author HomeFolder
 */
public class CardioSimUIController implements Initializable {
    @FXML ChoiceBox painChoiceBox = new ChoiceBox();
    @FXML ChoiceBox freqExcChoiceBox;
    @FXML ChoiceBox dietChoiceBox;
    @FXML ChoiceBox exerciseChoiceBox;
    @FXML Label exerciseLabel;
    @FXML Label exerciseTypeLabel;
    @FXML Label ageLabel;
    @FXML Label painLabel;
    @FXML Label dietLabel;
    @FXML Label nameLabel;
    @FXML Label calcLabel;
    @FXML TextField nameTextField;
    @FXML TextField ageTextField;
    Pain pain = new Pain();
    Exercise exc = new Exercise();
    Diet diet = new Diet();
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        this.painChoiceBox.setItems(pain.painOptions);
        this.dietChoiceBox.setItems(diet.dietOptions);
        this.freqExcChoiceBox.setItems(exc.excOptions);
        this.exerciseChoiceBox.setItems(exc.excType);
        this.ageTextField.setEditable(true);
        this.nameTextField.setEditable(true);
    }    
    
    public void handleButton(ActionEvent e) {
        
    }
    
}
