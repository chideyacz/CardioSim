/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardiosimulator;

import java.util.ArrayList;
import java.util.Arrays;
import javafx.collections.ObservableList;

/**
 *
 * @author HomeFolder
 */
public class Diet extends Health {
    private double factor;
    
    protected String a = new String("Balance of essential foods, infrequently fast-foods");
    protected String b = new String("Sometimes balance of healthy foods and fast foods");
    protected String c = new String("Infrequently healthy foods, mostly fast-foods");
    protected ObservableList<String> dietOptions;
    
    public Diet () {
        dietOptions.add(a);
        dietOptions.add(b);
        dietOptions.add(c);
    }
    
    
    /*public ArrayList<String> dietArray = new ArrayList(Arrays.asList(
         new String("Balance of essential foods and some fast-foods"),
         new String("Sometimes balance of healthy foods and fast foods"),
         new String("Infrequently healthy foods, mostly fast-foods")
    ));*/
    
    @Override
    public double calcHealth(String string) {
        try {
            if (string == a) {
               factor = .02;
           }
           if (string == b) {
               factor = .03;
           }
           if (string == c) {
               factor = .09;
           }
        }
       catch(Exception e) {
           System.out.println(e.getMessage() + " Please choose an option from the choicebox");
       }
        
       //does having the return here influence your calculation?
        return factor;
        
    }
    
    
        
    
    
}
