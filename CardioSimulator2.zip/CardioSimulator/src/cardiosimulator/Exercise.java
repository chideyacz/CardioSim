/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardiosimulator;

import java.util.ArrayList;
import javafx.collections.ObservableList;

/**
 *
 * @author HomeFolder
 */
public class Exercise extends Health{
    
    protected String a = new String("1-2 times a week");
    protected String b = new String("3-4 times a week");
    protected String c = new String("5+ times sa week");
    private double factor;
    
    protected ObservableList<String> excOptions;
    protected ObservableList<String> excType;
    
    public Exercise () {
        excOptions.add(a);
        excOptions.add(b);
        excOptions.add(c);
        
    }

    @Override
    public double calcHealth(String string) throws Exception {
       try {
        if (string == a) {
           factor = .1;
       }
       if (string == b) {
           factor = .06;
       }
       if (string == c) {
           factor = .03;
       }
       }
       catch(Exception e) {
           System.out.println(e.getMessage() + " Please choose an option from the choicebox");
       }
        
       //does having the return here influence your calculation?
        return factor;
    }
}
