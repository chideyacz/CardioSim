/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardiosimulator;

/**
 *
 * @author HomeFolder
 */
public abstract class Health {
    
    protected String name;
    protected String age;
    protected User user;
    
    
    public abstract double calcHealth(String string) throws Exception;
    
}
