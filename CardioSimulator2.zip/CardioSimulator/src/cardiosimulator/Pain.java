/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardiosimulator;

import java.util.ArrayList;
import javafx.collections.ObservableList;

/**
 *
 * @author HomeFolder
 */
public class Pain extends Health {
    
    private double factor;
    protected String a = new String("Mild chest pain");
    protected String b = new String("Moderate chest pain");
    protected String c =  new String("Extreme chest pain");
    protected String d = new String("Shortness of breath"); 
    protected String e = new String("Pain in neck, jaw, throat or back"); 
    protected String f = new String("No pain of this kind");
    protected ObservableList<String> painOptions;
    
    public Pain() {
       painOptions.add(a);
       painOptions.add(b);
       painOptions.add(c);
       painOptions.add(d);
       painOptions.add(e);
    }
    

    @Override
    public double calcHealth(String string) {
        try {
            if (string == a) {
               factor = .04;
           }
           if (string == b) {
               factor = .08;
           }
           if (string == c) {
               factor = .12;
           }
           if (string == d) {
               factor = .1;
           }
           if (string == e) {
               factor = .08;
           }
           if (string == f) {
               factor = 0;
           }
       }
       catch(Exception e) {
           System.out.println(e.getMessage() + " Please choose an option from the choicebox");
       }
        
       //does having the return here influence your calculation?
        return factor;
    }
    
}
    
