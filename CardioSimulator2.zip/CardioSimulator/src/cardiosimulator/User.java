/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cardiosimulator;

/**
 *
 * @author HomeFolder
 */
public abstract class User {
    protected int age;
    protected String name;
    
    public User (String name, int age) {
        this.age = age;
        this.name = name;
    }
    
    public int getAge() {
        return age;
    }
    public String getName() {
        return name;
    }
    
    
}
